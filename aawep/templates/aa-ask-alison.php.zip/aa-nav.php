<nav id="primary_nav_wrap">
<ul>
   <li class='tab'><a href="<?php bloginfo('url'); ?>/wei-live/overview/"  <?php if(is_page('overview')) :?> class="active" <?php endif; ?>>Overview</a></li>
    <li class='tab'><a href="<?php bloginfo('url'); ?>/wei-live/google-hangouts/"  <?php if(is_page('google-hangouts')) :?> class="active" <?php endif; ?>>Google Hangouts</a></li>
    <li class='tab'><a href="<?php bloginfo('url'); ?>/wei-live/wedbizhour/" <?php if(is_page('wedbizhour')) :?> class="active" <?php endif; ?>>WedBizHour</a></li>
    <li class='tab'><a href="<?php bloginfo('url'); ?>/wei-live/wei-tv/" <?php if(is_page('wei-tv')) :?> class="active" <?php endif; ?>>WEI TV</a></li>
    <li class='tab'><a href="<?php bloginfo('url'); ?>/wei-live/podcast-series/" <?php if(is_page('podcast-series')) :?> class="active" <?php endif; ?>>Podcast Series</a></li>
    <li class='tab'><a href="<?php bloginfo('url'); ?>/wei-live/ask-alison/" <?php if(is_page('ask-alison')) :?> class="active" <?php endif; ?>>Ask Alison</a></li>
    <li class='tab'><a href="<?php bloginfo('url'); ?>/wei-live/wei-inspire/" <?php if(is_page('wei-inspire')) :?> class="active" <?php endif; ?>>WEI Inspire</a></li>
</ul>
</nav> 



